package org.example.bussinesmanage;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BussinesManageApplicationTests {

	@Test
	void contextLoads() {
	}

}
