package org.example.bussinesmanage;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BussinesManageApplication {

	public static void main(String[] args) {
		SpringApplication.run(BussinesManageApplication.class, args);
	}

}
